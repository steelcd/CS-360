package com.zybooks.cs_360_project_3_stevens_chris;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class EditRecord extends AppCompatActivity {

    private int stockAdjustFactor;
    private BigDecimal bigDecimalQuantity;
    private BigDecimal newStockQuantity;
    private String outOfStockMaterial;
    DatabaseHelper inventoryDb = new DatabaseHelper(this);

    private BigDecimal getBigDecimal(EditText editText, String message) {
        BigDecimal field;

        try{
            field = new BigDecimal(editText.getText().toString());
        } catch (NumberFormatException e) {
            editText.setError(message);
            return new BigDecimal(-1);
        }
        return field;
    }

    private Boolean sendSms() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        if (newStockQuantity.equals(new BigDecimal(0))) {
            List<String> phoneNumberList = new ArrayList<>();
            phoneNumberList = inventoryDb.getSmsNumbers();
            int numberRecipients = phoneNumberList.size();

            if (numberRecipients > 0){
                String toastMessage = "Out of stock sms sent to " + numberRecipients + " recipients";
                SmsManager smsManager = SmsManager.getDefault();

                for (String phoneNumber: phoneNumberList) {
                    smsManager.sendTextMessage(phoneNumber, null, outOfStockMaterial + " is out of stock.", null, null);
                }

                Toast.makeText(EditRecord.this ,toastMessage, Toast.LENGTH_SHORT).show();

                return true;
            }
            return false;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_record);

        // Get recordId
        Intent intent = getIntent();
        String recordId = intent.getStringExtra("recordId");

        // Fetch info from table
        DatabaseHelper inventoryDb = new DatabaseHelper(this);

        List<String> itemRecord = new ArrayList<>();
        itemRecord = inventoryDb.getInventoryItem(recordId);

        String material = itemRecord.get(1);
        String location = itemRecord.get(2);
        String quantity = itemRecord.get(3);
        bigDecimalQuantity = new BigDecimal(quantity);

        TextView itemName = findViewById(R.id.textViewActivityEditRecordItem);
        itemName.setText(material);

        TextView itemLocation = findViewById(R.id.textViewActivityEditRecordLocation);
        itemLocation.setText(location);

        TextView itemQuantity = findViewById(R.id.textViewActivityEditRecordQuantity);
        itemQuantity.setText(quantity);

        TextView adjustQuantityLabel = findViewById(R.id.textViewActivityEditRecordAdjustQuantityLabel);
        adjustQuantityLabel.setVisibility(TextView.INVISIBLE);

        EditText adjustQuantity = findViewById(R.id.editTextNumberDecimalActivityEditRecordAdjustQuantity);
        adjustQuantity.setVisibility(EditText.INVISIBLE);

        // Make adjust fields visible after user selects adjustment type
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull RadioGroup group, int checkedId) {
                Button saveButton = findViewById(R.id.buttonActivityEditRecordAdjustSave);
                saveButton.setEnabled(true);

                TextView adjustQuantityLabel = findViewById(R.id.textViewActivityEditRecordAdjustQuantityLabel);
                adjustQuantityLabel.setVisibility(TextView.VISIBLE);

                EditText adjustQuantity = findViewById(R.id.editTextNumberDecimalActivityEditRecordAdjustQuantity);
                adjustQuantity.setVisibility(EditText.VISIBLE);

                if (checkedId == R.id.radioButtonActivityEditRecordAddStock) {
                    stockAdjustFactor = 1;
                }
                else {
                    stockAdjustFactor = -1;
                }

            }
        });

        Button saveButton = findViewById(R.id.buttonActivityEditRecordAdjustSave);
        saveButton.setEnabled(false);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int rowsAffected;
                BigDecimal adjustQuantity = getBigDecimal(findViewById(R.id.editTextNumberDecimalActivityEditRecordAdjustQuantity), "Quantity required.");
                if (Objects.equals(adjustQuantity, new BigDecimal(-1))){
                    Toast.makeText(EditRecord.this ,R.string.internal_error, Toast.LENGTH_SHORT).show();
                    return;
                } else if (stockAdjustFactor == -1) {
                    if (adjustQuantity.compareTo(bigDecimalQuantity) > 0){
                        Toast.makeText(EditRecord.this ,R.string.stock_deficit_message, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    newStockQuantity = bigDecimalQuantity.subtract(adjustQuantity);
                    rowsAffected = inventoryDb.updateQuantity(recordId, newStockQuantity);
                }
                else {
                    newStockQuantity = bigDecimalQuantity.add(adjustQuantity);
                    rowsAffected = inventoryDb.updateQuantity(recordId, newStockQuantity);
                }
                if (rowsAffected == -1) {
                    Toast.makeText(EditRecord.this ,R.string.internal_error, Toast.LENGTH_SHORT).show();
                    return;
                }

                if (newStockQuantity.equals(new BigDecimal(0))) {
                    sendSms();
                }

                Intent intent = new Intent(EditRecord.this, InventoryTable.class);
                startActivity(intent);

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        Button saveButton = findViewById(R.id.buttonActivityEditRecordAdjustSave);
        saveButton.setEnabled(false);

        TextView adjustQuantityLabel = findViewById(R.id.textViewActivityEditRecordAdjustQuantityLabel);
        adjustQuantityLabel.setVisibility(TextView.INVISIBLE);

        EditText adjustQuantity = findViewById(R.id.editTextNumberDecimalActivityEditRecordAdjustQuantity);
        adjustQuantity.setVisibility(EditText.INVISIBLE);
    }
}