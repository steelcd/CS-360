package com.zybooks.cs_360_project_3_stevens_chris;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    private void clearEmail() {
        EditText userNameEditText = findViewById(R.id.editTextEmailAddress);
        userNameEditText.setText("");
    }

    private void clearPassword() {
        EditText passwordEditText = findViewById(R.id.editTextTextPassword);
        passwordEditText.setText("");
    }


    private String getEmail(){
        EditText userNameEditText = findViewById(R.id.editTextEmailAddress);
        String userName = userNameEditText.getText().toString();

        if(userName.isBlank()) {
            userNameEditText.setError(getString(R.string.email_required));
            return null;
        }
        else {
            return userName;
        }
    }

    private String getPassword(){
        EditText passwordEditText = findViewById(R.id.editTextTextPassword);
        String password = passwordEditText.getText().toString();

        if(password.isBlank()) {
            passwordEditText.setError(getString(R.string.password_required));
            return null;
        }
        else {
            return password;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHelper inventoryDb = new DatabaseHelper(this);



        Button loginButton = findViewById(R.id.buttonLogin);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                User mUser;
                String hashedPassword;
                String salt;
                String userName = getEmail();
                String password = getPassword();

                if(userName == null || password == null) {
                    return;
                }

                try {
                    mUser = new User(userName, password);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }

                //Try to fetch matching user record
                List<String> dbRecord;
                String dbUserName;
                String dbHashedPassword;
                String dbSalt;

                dbRecord = inventoryDb.getUserRecord(userName);
                dbUserName = dbRecord.get(0);
                dbHashedPassword = dbRecord.get(1);
                dbSalt = dbRecord.get(2);

                //Complete record found
                if (dbUserName != null && dbHashedPassword != null && dbSalt != null) {
                    try {
                        mUser.hashPassword(dbSalt);
                    } catch (NoSuchAlgorithmException e) {
                        throw new RuntimeException(e);
                    }
                    String uiHashedPassword = mUser.getHashedPassword();

                    if (!Objects.equals(uiHashedPassword, dbHashedPassword)) {
                        //Incorrect password
                        Toast.makeText(MainActivity.this,R.string.incorrect_password,Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                else if (dbUserName == null){
                    //User name not found
                    Toast.makeText(MainActivity.this,R.string.incorrect_email, Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    //Incomplete record found
                    Toast.makeText(MainActivity.this,R.string.internal_error, Toast.LENGTH_LONG).show();
                    return;
                }

                Intent intent = new Intent(MainActivity.this, InventoryTable.class);
                startActivity(intent);
                finish();
                }

            });

        Button createAccountButton = findViewById(R.id.buttonCreateAccount);
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                User mUser;
                String hashedPassword;
                String salt;
                long recordId;
                String userName = getEmail();
                String password = getPassword();

                if(userName == null || password == null) {
                    return;
                }

                try {
                    mUser = new User(userName, password);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }

                //Try to fetch matching user record
                List<String> dbRecord;
                String dbUserName;
                dbRecord = inventoryDb.getUserRecord(userName);
                dbUserName = dbRecord.get(0);

                if (dbUserName != null) {
                    //Username already created
                    Toast.makeText(MainActivity.this,R.string.account_exists, Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    mUser.hashPassword(null);
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
                hashedPassword = mUser.getHashedPassword();
                salt = mUser.getSalt();

                //Insert user into DB
                recordId = inventoryDb.addUserRecord(userName, hashedPassword, salt);

                if (recordId != -1) {
                    Toast.makeText(MainActivity.this,R.string.account_created, Toast.LENGTH_LONG).show();
                    clearEmail();
                    clearPassword();
                }
                else {
                    Toast.makeText(MainActivity.this,R.string.error_saving_account, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
