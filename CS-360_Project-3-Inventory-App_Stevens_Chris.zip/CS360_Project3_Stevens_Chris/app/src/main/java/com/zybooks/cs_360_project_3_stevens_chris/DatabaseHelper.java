package com.zybooks.cs_360_project_3_stevens_chris;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_HASHEDPASSWORD = "hashedpassword";
        private static final String COL_SALT = "salt";
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEMNAME = "itemname";
        private static final String COL_LOCATION = "location";
        private static final String COL_QUANTITY = "quantity";
    }

    private static final class SmsTable {
        private static final String TABLE = "smsNumbers";
        private static final String COL_ID = "_id";
        private static final String COL_PHONENUMBER = "phonenumber";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_HASHEDPASSWORD + " text, " +
                UserTable.COL_SALT + " text);");
        //Write default user record
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, "test");
        values.put(UserTable.COL_HASHEDPASSWORD, "d4e2fe66b1ca866634e47ce6c8af9da193e2c73262c5fb929ca13cc4dfeedfa99410c91e76c3a9605c5c35b4eded99b465d79085d9e2fcc1cb5bab5c7fd7dbef");
        values.put(UserTable.COL_SALT, "20665ccf71e309db31f3151f0ed8b6df");
        long userId = db.insert(UserTable.TABLE, null, values);

        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEMNAME + " text, " +
                InventoryTable.COL_LOCATION + " text, " +
                InventoryTable.COL_QUANTITY + " text);");
        //Write default material records
        ContentValues values1 = new ContentValues();
        values1.put(InventoryTable.COL_ITEMNAME, "Material1");
        values1.put(InventoryTable.COL_LOCATION, "Bin1");
        values1.put(InventoryTable.COL_QUANTITY, "1.123");
        db.insert(InventoryTable.TABLE, null, values1);

        ContentValues values2 = new ContentValues();
        values2.put(InventoryTable.COL_ITEMNAME, "Material2");
        values2.put(InventoryTable.COL_LOCATION, "Bin2");
        values2.put(InventoryTable.COL_QUANTITY, "2.123");
        db.insert(InventoryTable.TABLE, null, values2);

        ContentValues values3 = new ContentValues();
        values3.put(InventoryTable.COL_ITEMNAME, "Material3");
        values3.put(InventoryTable.COL_LOCATION, "Bin3");
        values3.put(InventoryTable.COL_QUANTITY, "3.123");
        db.insert(InventoryTable.TABLE, null, values3);


        db.execSQL("create table " + SmsTable.TABLE + " (" +
                SmsTable.COL_ID + " integer primary key autoincrement, " +
                SmsTable.COL_PHONENUMBER + " text);");
        //Write default user record
        ContentValues values4 = new ContentValues();
        values.put(SmsTable.COL_PHONENUMBER, "5551234567");
        long phoneNumberId = db.insert(SmsTable.TABLE, null, values4);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    public List<String> getUserRecord(String userName) {
        SQLiteDatabase db = getReadableDatabase();
        String dbUserName = null;
        String hashedPassword = null;
        String salt = null;
        List<String> returnList = new ArrayList<String>();

        String sql = "select " + UserTable.COL_USERNAME + ", " + UserTable.COL_HASHEDPASSWORD + ", " + UserTable.COL_SALT + " from " + UserTable.TABLE + " where " + UserTable.COL_USERNAME + " = ?;";
        Cursor cursor = db.rawQuery(sql, new String[] { userName });
        if (cursor.moveToFirst()) {
            do {
                dbUserName = cursor.getString(0);
                hashedPassword = cursor.getString(1);
                salt = cursor.getString(2);
            } while (cursor.moveToNext());
        }
        cursor.close();

        returnList.add(dbUserName);
        returnList.add(hashedPassword);
        returnList.add(salt);
        return returnList;
    }

    public long addUserRecord(String userName, String hashedPassword, String salt) {
        SQLiteDatabase db = getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, userName);
        values.put(UserTable.COL_HASHEDPASSWORD, hashedPassword);
        values.put(UserTable.COL_SALT, salt);

        return db.insert(UserTable.TABLE, null, values);
    }

    public List<List<String>> getInventory() {
        SQLiteDatabase db = getReadableDatabase();
        List<List<String>> dbList = new ArrayList<>();
        String dbRecordId = null;
        String dbMaterial = null;
        String dbLocation = null;
        String dbQuantity = null;

        String sql = "select * from " + InventoryTable.TABLE + ";";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                List<String> recordList = new ArrayList<>();
                dbRecordId = cursor.getString(0);
                dbMaterial = cursor.getString(1);
                dbLocation = cursor.getString(2);
                dbQuantity = cursor.getString(3);
                recordList.add(dbRecordId);
                recordList.add(dbMaterial);
                recordList.add(dbLocation);
                recordList.add(dbQuantity);
                dbList.add(recordList);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return dbList;

    }

    public List<String> getInventoryItem(String recordId) {
        SQLiteDatabase db = getReadableDatabase();
        List<String> inventoryItem = new ArrayList<>();
        String dbRecordId = null;
        String dbMaterial = null;
        String dbLocation = null;
        String dbQuantity = null;

        String sql = "select * from " + InventoryTable.TABLE + " where " + InventoryTable.COL_ID + " = ?;";
        Cursor cursor = db.rawQuery(sql, new String[] { recordId });
        if (cursor.moveToFirst()) {
            do {
                dbRecordId = cursor.getString(0);
                dbMaterial = cursor.getString(1);
                dbLocation = cursor.getString(2);
                dbQuantity = cursor.getString(3);
                inventoryItem.add(dbRecordId);
                inventoryItem.add(dbMaterial);
                inventoryItem.add(dbLocation);
                inventoryItem.add(dbQuantity);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return inventoryItem;

    }

    public int deleteItemById(String id) {
        SQLiteDatabase db = getReadableDatabase();
        String whereClause = "_id = ?";
        String[] whereArgs = { id };
        return db.delete(InventoryTable.TABLE, whereClause, whereArgs);
    }

    public long addItem(String itemName, String location, BigDecimal quantity) {
        SQLiteDatabase db = getReadableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEMNAME, itemName);
        values.put(InventoryTable.COL_LOCATION, location);
        values.put(InventoryTable.COL_QUANTITY, quantity.toPlainString());

        return db.insert(InventoryTable.TABLE, null, values);

    }


    public int updateQuantity(String id, BigDecimal quantity) {
        SQLiteDatabase db = getReadableDatabase();

        ContentValues values = new ContentValues();
        String stringQuantity = quantity.toString();
        values.put(InventoryTable.COL_QUANTITY, stringQuantity);

        String whereClause = "_id = ?";
        String[] whereArgs = {String.valueOf(id)};

        int rowsAffected = db.update(InventoryTable.TABLE, values, whereClause, whereArgs);
        return rowsAffected;

    }

    public List<String> getSmsNumbers() {
        SQLiteDatabase db = getReadableDatabase();
        List<String> smsList = new ArrayList<>();
        String dbPhoneNumber = null;

        String sql = "select " + SmsTable.COL_PHONENUMBER + " from " + SmsTable.TABLE + ";";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                dbPhoneNumber = cursor.getString(0);
                smsList.add(dbPhoneNumber);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return smsList;

    }

    public long addSmsNumber(String phoneNumber) {
        SQLiteDatabase db = getReadableDatabase();

        ContentValues values = new ContentValues();
        values.put(SmsTable.COL_PHONENUMBER, phoneNumber);

        return db.insert(SmsTable.TABLE, null, values);
    }
}
