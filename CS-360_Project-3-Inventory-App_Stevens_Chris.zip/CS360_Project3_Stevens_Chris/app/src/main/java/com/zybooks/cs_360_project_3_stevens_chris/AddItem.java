package com.zybooks.cs_360_project_3_stevens_chris;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.math.BigDecimal;
import java.util.Objects;

public class AddItem extends AppCompatActivity {

    private String getString(EditText editText, String message){

        String field = editText.getText().toString();

        if(field.isBlank()) {
            editText.setError(message);
            return null;
        }
        else {
            return field;
        }
    }

    private BigDecimal getBigDecimal(EditText editText, String message){
        BigDecimal field;

        try{
            field = new BigDecimal(editText.getText().toString());
        } catch (NumberFormatException e) {
            editText.setError(message);
            return new BigDecimal(-1);
        }
            return field;
        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        DatabaseHelper inventoryDb = new DatabaseHelper(this);

        Button saveButton = findViewById(R.id.buttonSave);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mItem;
                String mLocation;
                BigDecimal mQuantity;
                long insertId;

                mItem = getString(findViewById(R.id.editTextItem), "Item name required");
                mLocation = getString(findViewById(R.id.editTextLocation), "Location required.");
                mQuantity = getBigDecimal(findViewById(R.id.editTextQuantity), "Quantity required.");
                if (mItem == null || mLocation == null || Objects.equals(mQuantity, new BigDecimal(-1))) {
                    return;
                }

                insertId = inventoryDb.addItem(mItem, mLocation, mQuantity);

                if (insertId == -1){
                    Toast.makeText(AddItem.this,R.string.save_item_error, Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent(AddItem.this, InventoryTable.class);
                startActivity(intent);

            }
        });


    }
}