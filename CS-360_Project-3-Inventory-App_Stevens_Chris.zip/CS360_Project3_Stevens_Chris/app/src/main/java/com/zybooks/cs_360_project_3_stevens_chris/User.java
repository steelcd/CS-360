package com.zybooks.cs_360_project_3_stevens_chris;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class User {
    private String username;
    private String password;
    private String phoneNumber;
    private String hashedPassword;
    private String salt;

    public User(String username, String password) throws NoSuchAlgorithmException {
        setUsername(username);
        setPassword(password);
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String hashPassword(String saltIn) throws NoSuchAlgorithmException {
        SecureRandom random = new SecureRandom();
        byte[] saltBytes = new byte[16];
        MessageDigest md = MessageDigest.getInstance("SHA-512");

        if(saltIn == null) {
            random.nextBytes(saltBytes);
            this.salt = bytesToHex(saltBytes);
        }
        else {
            this.salt = saltIn;
            saltBytes = hexToBytes(salt);
        }

        md.update(saltBytes);

        byte[] hashedPasswordBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));

        this.hashedPassword = bytesToHex(hashedPasswordBytes);

        return this.hashedPassword;
    }

    private static byte[] hexToBytes(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (int i = 0; i < hash.length; i++) {
            String hex = Integer.toHexString(0xff & hash[i]);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public String getHashedPassword() {
        return hashedPassword;
    }

    public String getSalt() {
        return salt;
    }
}
