package com.zybooks.cs_360_project_3_stevens_chris;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;

import java.util.ArrayList;
import java.util.List;

public class InventoryTable extends AppCompatActivity {

    // helper for dp
    private int dp(int v) {
        return Math.round(
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics())
        );
    }

    private TableLayout tableLayout;
    DatabaseHelper inventoryDb = new DatabaseHelper(this);
    private boolean editMode = false;
    private ColorStateList originalBgTint;
    private Boolean smsPermission;
    private final int REQUEST_SMS_CODE = 0;

    private void buildTable(){
        //Check if table already populated and remove views
        List<List<String>> dbList = new ArrayList<>();
        int childCount = tableLayout.getChildCount();
        if (childCount > 1) {
            tableLayout.removeViews(1, childCount - 1);
        }

        //Get entire inventory list
        dbList = inventoryDb.getInventory();

        for (List<String> record : dbList) {

            String recordId = record.get(0);
            String material = record.get(1);
            String location = record.get(2);
            String quantity = record.get(3);

            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

            TextView materialTextView = new TextView(this);
            materialTextView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
            materialTextView.setText(material);
            row.addView(materialTextView);

            TextView locationTextView = new TextView(this);
            locationTextView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
            locationTextView.setText(location);
            row.addView(locationTextView);

            TextView quantityTextView = new TextView(this);
            quantityTextView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
            quantityTextView.setText(quantity);
            row.addView(quantityTextView);

            Button deleteButton = new Button(this);
            TableRow.LayoutParams delLp = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT);
            delLp.gravity = Gravity.END;
            deleteButton.setLayoutParams(delLp);
            int color = ContextCompat.getColor(this, R.color.colorRedDelete);
            ColorStateList colorStateList = ColorStateList.valueOf(color);
            deleteButton.setBackgroundTintList(colorStateList);
            deleteButton.setMinimumWidth(dp(50));
            deleteButton.setMinWidth(dp(50));
            deleteButton.setMinimumHeight(dp(30));
            deleteButton.setMinHeight(dp(30));
            deleteButton.setPadding(0, 0, 0, 0);
            row.addView(deleteButton);
            tableLayout.addView(row);

            row.setOnClickListener(v -> {
                if (editMode) {
                    Intent intent = new Intent(this, EditRecord.class);
                    intent.putExtra("recordId", recordId);
                    startActivity(intent);
                }
            });

            deleteButton.setOnClickListener(v -> {
                int rowsAffected = inventoryDb.deleteItemById(recordId);
                tableLayout.removeView((row));
            });
        }

    }

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory_table);
        tableLayout = findViewById(R.id.tableLayout);
        buildTable();

        Button smsButton = findViewById(R.id.buttonSmsNotification);
        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                smsPermission = hasSendSmsPermissions();

                if (!smsPermission) {
                    Toast.makeText(InventoryTable.this,"No sms persmissions", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent(InventoryTable.this, Sms.class);
                startActivity(intent);
            }
        });

        Button addItemButton = findViewById(R.id.buttonAddItem);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryTable.this, AddItem.class);
                startActivity(intent);
            }
        });

        Button editModeButton = findViewById(R.id.buttonEditQty);
        originalBgTint = ViewCompat.getBackgroundTintList(editModeButton);
        editModeButton.setOnClickListener(v -> {
            editMode = !editMode;

            if (editMode){
                int color = ContextCompat.getColor(this, R.color.colorRedDelete);
                ColorStateList colorStateList = ColorStateList.valueOf(color);
                editModeButton.setBackgroundTintList(colorStateList);
                Toast.makeText(this, "Tap a row to edit", Toast.LENGTH_SHORT).show();
            }
            else {
                editModeButton.setBackgroundTintList(originalBgTint);
                Toast.makeText(this, "Edit mode off", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        editMode = false;
        buildTable();
        Button editModeButton = findViewById(R.id.buttonEditQty);
        editModeButton.setBackgroundTintList(originalBgTint);
    }

    private boolean hasSendSmsPermissions() {
        String smsPermission = Manifest.permission.SEND_SMS;
        if (ContextCompat.checkSelfPermission(this, smsPermission)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, smsPermission )) {
                new AlertDialog.Builder(this)
                        .setTitle("SMS Permission Required")
                        .setMessage("Send SMS permission is required to send low inventory notifications.")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(InventoryTable.this,
                                        new String[] { smsPermission }, REQUEST_SMS_CODE);
                            }
                        })
                        .show();
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[] { smsPermission }, REQUEST_SMS_CODE);
            }
            return false;
        }
        return true;
    }


}