package com.zybooks.cs_360_project_3_stevens_chris;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Sms extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        DatabaseHelper inventoryDb = new DatabaseHelper(this);
        EditText editTextPhoneNumber = findViewById(R.id.editTextPhone);
        Button sendSmsButton = findViewById(R.id.buttonAddSms);
        sendSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = editTextPhoneNumber.getText().toString().trim();

                if(phoneNumber.isBlank()) {
                    editTextPhoneNumber.setError("Phone number required");
                    return;
                }

                long recordId = inventoryDb.addSmsNumber(phoneNumber);
                if (recordId == -1) {
                    Toast.makeText(Sms.this,R.string.internal_error, Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(Sms.this, InventoryTable.class);
                startActivity(intent);
            }
        });
    }

}
